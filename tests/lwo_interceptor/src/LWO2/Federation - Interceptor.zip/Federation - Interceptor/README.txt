INTERCEPTOR CLASS STARSHIP
==========================

==========================

Credit Information:
--------------------
Original Design by: Stuart Baldwin (narsil)
Lightwave Mesh by: Richard Mavery (mavek)

Copyright 2006 Narsil and Mavek Enterprises 

==========================

Technical Information:
-----------------------

* Originally Created with Lightwave 8.0

==========================

All images created with this mesh MUST have proper credit information applied. This is the one golden rule 
that is enforced by the 3D community as a whole so if I don't find you someone else will grrr....

Credits should be applied as follows...

********************************************
Interceptor : narsil/mavek 
********************************************

There comes a time when you just have to put the pens down, times up.  There is probably loads more
I could do with this mesh but it would probably only be small and incremental.  The mesh is however in a
state when it can be released and maybe other people can make more out of it than I can now.  So here is
my mesh, potentially flawed but maybe the base for a rev2 some time in the future.

The scenes included with this mesh are :

interceptor_lighting.lws : Which is the Interceptor mesh put together with lighting and slider for nacelle
control with the interceptor registry.
buccaneer_lighting.lws : Which is the Interceptor mesh put together with lighting and slider for nacelle
control with the Buccaneer registry.
interceptor_ortho.lws : A basic scene setup to produce orthographic images of the Interceptor once lit.
interceptor_action.lws : Another basic shot of the Interceptor in space.

The Interceptor is under slider control for the postion of the nacelles. The position can be varied
for 0 to 35 degrees.  It technically is only for entering into warp but it is a pose that looks good
in standard static shots so artistic discretion is advised.

All action an poses need to be controlled by the INTERCEPTOR_ROOT objext highlighted in red of the objects.
(don't use the hull).

Please don't edit or alter this mesh, particularily kitbashing, conversions are allowed but give me a shout if you
do as it might be cool to release that too.

You are allowed however to change the registry number and name.  I have included two registries for this ship
the Interceptor and the Buccaneer with the lighting setup up for each.  Also included is a interceptor
registry kit which has singled out all the mesh surfaces that need the registry.  Each part of the hull
has been raised away from it normal position so that when the registry is drilled into this section
of hull and re-applied back to the main mesh the registry will be floating above the hull and not directly
flush, which causes funny things in LW.  On layer two are all the registry elements for the interceptor
you can use this layer as a guide to create a new registry.

The mesh is broken into 6 elements, the hull and each nacelle, with the registry for each of them applied
seperately, this allows easy registry change and have the nacelles animatable. I would explain any further
as the scenes should speak for them selves.

If I can take some time out acknowledge a few people. I'd like to thank Alain Rivard, al3d, for generally 
putting his work out there so that other beginners can see what we are aiming for and specifically for 
giving me input on how to do window boxes and supplying me with images that I can use, cheers bud.

And I'd also like to thank and acknowledge Dennis Bailey and thank him for releasing his refit Enterprise. I've
been all over that model and learned so much from his technique, I hope you release more, it is appreciated.

Of course none of this would be possible without Stuart Baldwin, narsil, original design so thanks as well 
for that and will probably be the source of more of my work.

So enjoy the mesh, use proper credit and if you use it please send me on the image or a link to it as I want
to see it in action aswell. C&C are still welcome.


Cheers!

mavek,

mavek.cg@gmail.com

=====================

More of narsil work can be found at this website :

http://www.webcreation.ca/websites/millennium/

And here are the specifications for the Interceptor class
SPECIFICATIONS

Ship info:
Name: U.S.S. Interceptor
Starfleet Registry: NX-77197 (Prototype)
Class: Interceptor
Type: Patrol Combatant
Construction Facility: Binford Shipyards, Neptue, Sol Sector
Crew Complement: 84
Emergency Evacuation Limit: 300

Performance:
Cruising Velocity: Warp Factor 6.5
Maximum Velocity: Warp Factor 9.98

Duration:
Standard Mission: 3 Years
Recommended Yard Overhaul: 7 Y ears

Populsion Systems:
Warp: (2) Lockhead Martin Y-24 Advanced Linear Warp Drive Units
Impulse: (2) FIG-4 Subatomic Unified Energy Impulse Units

Tactical Systems:
11 Type X Collimated Phaser Arrays
2 Type IX Pulse Phaser Cannons
1 Fore, 1 Aft Mk 95 Direct-Fire Torpedo Launchers
FSS Advanced Regenerative Force Field and Deflector Control System
Mithril Class Ablative Hull Armour

Primary Computer System:
M-16 Bio-Neural Gelpack Isolinear III Processor

Embark Craft (Typical):
1 Orion Class Shuttlecraft
2 Type 19 Shuttlepods
2 Work Bee General Utility Craft
1 Morpheus Class Runabout

Embark Craft (Mission Specific):
1 Type 4A Aqua Shuttlecraft
1 Savior Class Dropship

Sister Ships:
U.S.S. Firefly NCC-77198
U.S.S. Dauntless NCC-77199
U.S.S. Stingray NCC_77200
U.S.S. Protector NCC-77201
U.S.S. Millennium NCC-77202
U.S.S. Buccaneer NCC-77203
U.S.S. Raptor NCC-77204
U.S.S. Highlander NCC-77205
U.S.S. Falcon NCC-77206
U.S.S. Gladiator NCC-77207
U.S.S. Repulse NCC-77208

Narsil's 2d work on SFM can be found here, new link after SFM crash:
http://www.scifi-meshes.com/forums/2d-wips/340-interceptor-class-tech-manual.html

A partial WIP for this mesh can be found here :
http://www.scifi-meshes.com/forums/3d-wips/79-st-interceptor-class.html

I have uploaded all the WIP to my, at the moment brand new, picasa web site, it can be found here :
http://picasaweb.google.com/mavek.cg/Interceptor

Also sometimes i try and get some work done for the ST-Endeavour project check it out at :
Star Trek: Endeavour - http://undercity.co.nz/st-endeavour/